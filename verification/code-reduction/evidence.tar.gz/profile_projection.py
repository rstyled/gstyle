import os,subprocess
from pathlib import Path
out=Path('/home/shanejonas/.cache/gstyle-reduction-evidence')
template=(out/'projection_benchmark.txt').read_text()
for phase,root,call in [('before',Path('/home/shanejonas/.cache/gstyle-self-audit-20261022/source'),'toFacts(ex.Funcs)'),('after',Path('/home/shanejonas/.cache/gstyle-reduction-worktree'),'ex.PatternFacts()')]:
 p=root/'application/patterncheck/reduction_profile_test.go'
 if p.exists():raise RuntimeError('profile path already exists')
 p.write_text(template.replace('PROJECT',call))
 try:
  args=['go','test','-buildvcs=false','./application/patterncheck','-run','^$','-bench','^BenchmarkReportProjection$','-benchtime=1s','-count=3','-benchmem','-cpuprofile',str(out/(phase+'.cpu.pprof')),'-memprofile',str(out/(phase+'.mem.pprof')),'-o',str(out/(phase+'-profile.test'))]
  with (out/(phase+'-profile.log')).open('wb') as log:
   subprocess.run(args,cwd=root,env=dict(os.environ,GOMAXPROCS='2'),stdout=log,stderr=subprocess.STDOUT,check=True)
 finally:p.unlink()
print('Profiles complete')
