import hashlib,json,shutil,subprocess,sys
from pathlib import Path
ROOT=Path('/home/shanejonas/.cache/gstyle-self-audit-20261022/source')
OUT=Path('/home/shanejonas/.cache/gstyle-reduction-evidence')
phase,binary=sys.argv[1:]
results=[]
commands=[['check','--format','json','.'],['patterns','--format','json','.'],['next','.'],['score','.'],['fix','.'],['fix','--kind','parameterize','.'],['patterns','--format','pdg-json','.']]
for name in ['single','guard','traitmethod','nilerr_precision','index_precision','nil_precision']:
 fixture=OUT/'cli-input'/name
 shutil.rmtree(fixture,ignore_errors=True);shutil.copytree(ROOT/'application/patterncheck/testdata'/name,fixture)
 for index,args in enumerate(commands+[['fix','--apply','.'],['fix','--apply','.']]):
  result=subprocess.run([binary,*args],cwd=fixture,capture_output=True,timeout=40)
  entry={'case':name,'command':args,'exit':result.returncode,'stdout':result.stdout.decode(),'stderr':result.stderr.decode()}
  if result.returncode not in [0,1]:raise RuntimeError(entry)
  if index>=len(commands):entry['files']={str(p.relative_to(fixture)):p.read_text() for p in sorted(fixture.rglob('*.go'))}
  results.append(entry)
 print(phase,name,'completed',flush=True)
# A source analysis error must retain its hard-failure status.
fixture=OUT/'cli-input/invalid';fixture.mkdir(parents=True,exist_ok=True)
(fixture/'go.mod').write_text('module invalid.example/reduction\n\ngo 1.26.0\n')
(fixture/'broken.go').write_text('package broken\nfunc Broken(){ undefined() }\n')
r=subprocess.run([binary,'check','--format','json','.'],cwd=fixture,capture_output=True,timeout=40)
if r.returncode!=2:raise RuntimeError('invalid source did not fail closed')
results.append({'case':'invalid','command':['check','--format','json','.'],'exit':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()})
(OUT/(phase+'-cli.json')).write_text(json.dumps(results,indent=2)+'\n')
if phase=='after':
 before=json.loads((OUT/'before-cli.json').read_text())
 if before!=results:
  diffs=[{'case':a['case'],'command':a['command'],'fields':[k for k in a if a[k]!=b.get(k)]} for a,b in zip(before,results) if a!=b]
  (OUT/'cli-differences.json').write_text(json.dumps(diffs,indent=2)+'\n')
  raise RuntimeError('CLI behavior differs; see cli-differences.json')
 print('PASS',len(results),'identical command results, including generated source and hard failure')
